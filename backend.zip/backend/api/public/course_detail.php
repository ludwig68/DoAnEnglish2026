<?php
// backend/api/public/course_detail.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . '/../../config/db.php';

// Lấy ID khóa học từ URL (Ví dụ: course_detail.php?id=1)
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Mã khóa học không hợp lệ!']);
    exit;
}

try {
    // Lấy thông tin khóa học từ Database
    $stmt = $pdo->prepare("
        SELECT c.id, c.title, c.description, c.image_url, c.level, c.fee, cat.name as category_name
        FROM courses c
        LEFT JOIN categories cat ON c.category_id = cat.id
        WHERE c.id = ?
    ");
    $stmt->execute([$id]);
    $course = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$course) {
        echo json_encode(['status' => 'error', 'message' => 'Không tìm thấy khóa học này!']);
        exit;
    }

    // Tạm thời mô phỏng số học viên, lợi ích và lộ trình (Sau này bạn có thể tạo bảng lessons riêng trong DB)
    $course['students_count'] = rand(500, 3000);
    $course['benefits'] = [
        "Nắm vững toàn bộ kiến thức trọng tâm của khóa học.",
        "Thực hành qua các bài tập thực tế sát với môi trường thi/làm việc.",
        "Được hỗ trợ giải đáp thắc mắc 24/7 từ đội ngũ giảng viên.",
        "Cấp chứng chỉ hoàn thành sau khi kết thúc khóa học."
    ];
    $course['lessons'] = [
        ['title' => 'Chương 1: Giới thiệu & Khởi động', 'items' => 3],
        ['title' => 'Chương 2: Kiến thức nền tảng', 'items' => 5],
        ['title' => 'Chương 3: Thực hành chuyên sâu', 'items' => 8],
        ['title' => 'Chương 4: Tổng kết & Đánh giá', 'items' => 2],
    ];

    echo json_encode([
        'status' => 'success',
        'data' => $course
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Lỗi Database: ' . $e->getMessage()]);
}
?>