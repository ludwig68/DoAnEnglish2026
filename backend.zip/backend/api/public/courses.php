<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . '/../../config/db.php';

try {
    // 1. Lấy danh sách Danh mục (Categories)
    $stmtCat = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
    $categories = $stmtCat->fetchAll(PDO::FETCH_ASSOC);
    
    // Thêm mục "Tất cả" lên đầu
    array_unshift($categories, ['id' => 0, 'name' => 'Tất cả khóa học']);

    // 2. Lấy danh sách Khóa học (Courses)
    // Dùng LEFT JOIN để đếm số học viên (nếu sau này bạn có bảng enrollments)
    // Hiện tại lấy cơ bản từ bảng courses
    $stmtCourse = $pdo->query("
        SELECT id, category_id as categoryId, title as name, description, 
               image_url as imageUrl, level, fee 
        FROM courses 
        ORDER BY id DESC
    ");
    $courses = $stmtCourse->fetchAll(PDO::FETCH_ASSOC);

    // Xử lý lại dữ liệu khóa học trước khi gửi lên Vue
    foreach ($courses as &$course) {
        $course['fee'] = (float)$course['fee'];
        $course['isFree'] = ($course['fee'] == 0);
        $course['students_count'] = rand(100, 2000); // Tạm random số học viên vì chưa có bảng enrollments
    }

    echo json_encode([
        'status' => 'success',
        'categories' => $categories,
        'courses' => $courses
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>