<?php
// backend/api/admin/users.php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../utils/Validator.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents("php://input"), true);

try {
    switch ($method) {
        // 1. LẤY DANH SÁCH USER (GET)
        case 'GET':
            // Bỏ cột password ra khỏi kết quả để bảo mật
            $stmt = $pdo->query("SELECT id, full_name, email, role, status, DATE_FORMAT(created_at, '%d/%m/%Y') as created_at FROM users ORDER BY id DESC");
            $users = $stmt->fetchAll();
            echo json_encode(['status' => 'success', 'data' => $users]);
            break;

        // 2. THÊM TÀI KHOẢN MỚI (POST)
        case 'POST':
            $full_name = $data['full_name'] ?? '';
            $email = $data['email'] ?? '';
            $password = $data['password'] ?? '';
            $role = $data['role'] ?? 'student';
            $status = $data['status'] ?? 'active';

            // Kiểm tra email tồn tại
            $stmtCheck = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmtCheck->execute([$email]);
            if ($stmtCheck->fetch()) {
                echo json_encode(['status' => 'error', 'message' => 'Email đã tồn tại!']);
                exit;
            }

            // Mã hóa mật khẩu và chèn vào DB
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$full_name, $email, $hash, $role, $status]);

            echo json_encode(['status' => 'success', 'message' => 'Tạo tài khoản thành công!']);
            break;

        // 3. CẬP NHẬT TÀI KHOẢN (PUT)
        case 'PUT':
            $id = $data['id'] ?? 0;
            $full_name = $data['full_name'] ?? '';
            $role = $data['role'] ?? 'student';
            $status = $data['status'] ?? 'active';
            
            // Nếu có nhập mật khẩu mới thì mới cập nhật mật khẩu
            if (!empty($data['password'])) {
                $hash = password_hash($data['password'], PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, password = ?, role = ?, status = ? WHERE id = ?");
                $stmt->execute([$full_name, $hash, $role, $status, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, role = ?, status = ? WHERE id = ?");
                $stmt->execute([$full_name, $role, $status, $id]);
            }

            echo json_encode(['status' => 'success', 'message' => 'Cập nhật thông tin thành công!']);
            break;

        // 4. XÓA TÀI KHOẢN (DELETE)
        case 'DELETE':
            $id = $_GET['id'] ?? 0; // DELETE thường truyền ID qua URL query
            
            // Chống tự sát (Không cho tự xóa admin đang đăng nhập - sau này kiểm tra token thêm)
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);

            echo json_encode(['status' => 'success', 'message' => 'Đã xóa tài khoản!']);
            break;

        default:
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'Method Not Allowed']);
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Lỗi Database: ' . $e->getMessage()]);
}
?>